Graves Set Models (2009)

Author: Nicola "Neurological" Capecci
Website: http://www.neuro-lab.net
Contact: neurological (AT) neuro-lab (DOT) net

PROGRAMS USED

Autodesk 3D Studio Max 9
Adobe Photoshop 7.0

ADDICTIONAL RESOURCES

http://www.cgtextures.com - source material for texture


LICENSE

This work is licensed under a Creative Commons 3.0 Attribution-Non Commercial License.
(http://creativecommons.org/licenses/by-nc/3.0/)

You are free to share and modify this work to fit your needs.
I would like a mention to the credits of your project that use this work.






 